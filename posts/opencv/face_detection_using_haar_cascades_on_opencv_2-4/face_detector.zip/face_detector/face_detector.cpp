#include <opencv2/opencv.hpp>
#include <opencv2/objdetect/objdetect.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/legacy/legacy.hpp>
#include <iostream>
#include <stdio.h>
     
using namespace std;
using namespace cv;
     
//global variables
String cascade_name = "haarcascade_frontalface_alt.xml";
CascadeClassifier cascade;
     
     
//main function
int main(int argc, const char** argv)
{
     
  CvCapture* capture;
  Mat frame;
  Mat frameout;
    
  //load the cascades
  if(!cascade.load(cascade_name)){
    printf("--(!)Error loading\n"); 
    return -1; 
  }
     
  //read the video stream
  capture = cvCaptureFromCAM(-1);
    
  if(capture)  {
     
    while(true)  {
       
      frame = cvQueryFrame(capture);
      
      if(!frame.empty()) {
      }
      else {
        printf(" --(!) No captured frame -- Break!"); 
        break;
      }
      
      //FACE DETECTION
      std::vector<Rect> faces;
      Mat frame_gray;
      
      cvtColor( frame, frame_gray, CV_BGR2GRAY );
      equalizeHist( frame_gray, frame_gray );
      
      cascade.detectMultiScale( frame_gray, faces, 1.1, 2, 0|CV_HAAR_SCALE_IMAGE, Size(30, 30) );
      
      for( size_t i = 0; i < faces.size(); i++ ) {
        int point1x =  faces[i].x;
        int point1y = faces[i].y;
        int lengthxy = faces[i].width;
        rectangle(frame, Point(point1x,point1y), Point(point1x+lengthxy,point1y+lengthxy), Scalar(0,0,255), 1, 8, 0 );
        imshow("Face detection", frame );
      }
      
      int c = waitKey(10);
      if((char)c == 'q') { 
        break; 
      }
    
    }
  }
      
  return 0;
     
}
