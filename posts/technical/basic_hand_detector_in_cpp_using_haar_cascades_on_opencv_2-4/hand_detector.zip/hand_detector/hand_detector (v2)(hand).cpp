#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/objdetect/objdetect.hpp>
#include <iostream>
#include <stdio.h>

using namespace cv;
using namespace std;

Mat img;

vector<Rect> hands;

CascadeClassifier Hand;

int main()
{
  VideoCapture cap(0);
  char ch;
  namedWindow("Hand detection",CV_WINDOW_NORMAL);
  Hand.load("hand.xml");
  while(true)
  {
    cap>>img;
    Hand.detectMultiScale(img,hands,1.1,3,0|CV_HAAR_FIND_BIGGEST_OBJECT,Size(30,30));
    for(size_t  i=0; i < hands.size() ; i++)
    {
       int point1x =  hands[i].x;
       int point1y = hands[i].y;
       int lengthxy = hands[i].width;
       rectangle(img, Point(point1x,point1y), Point(point1x+lengthxy,point1y+lengthxy), Scalar(0,0,255), 1, 8, 0 );
       imshow("Hand detection", img );
     }  
    imshow("Hand detection",img);
    ch=waitKey(1);
    if(ch==27)
    { break; }  
  }
return 0;
}

